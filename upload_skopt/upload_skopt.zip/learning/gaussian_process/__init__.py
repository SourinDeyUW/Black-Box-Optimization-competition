from .gpr import GaussianProcessRegressor

__all__ = ("GaussianProcessRegressor")
